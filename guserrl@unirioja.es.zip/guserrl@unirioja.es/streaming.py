# Databricks notebook source
#Configuramos el autoloader y de donde vamos a obtener loas datos
#Esta vez vamos a obtener los datos de dataset preparados por databricks
#para la realizacion de pruebas
file_path = "/databricks-datasets/structured-streaming/events"
checkpoint_path = "/tmp/ss-tutorial/_checkpoint"

raw_df = (spark.readStream
    .format("cloudFiles")
    .option("cloudFiles.format", "json")
    .option("cloudFiles.schemaLocation", checkpoint_path)
    .load(file_path)
)

# COMMAND ----------

display(raw_df)

# COMMAND ----------

#Streaming permite hacer transformaciones
#En este caso vamos a añadir el path y tiempo de creacion del archivo
#Cuando llegeuen los datos esta instruccion los transformara 
from pyspark.sql.functions import col, current_timestamp

transformed_df = (raw_df.select(
    "*",
    col("_metadata.file_path").alias("source_file"),
    current_timestamp().alias("processing_time")
    )
)

# COMMAND ----------

display(transformed_df)

# COMMAND ----------

#Data sink
target_path = "/tmp/ss-tutorial/"
checkpoint_path = "/tmp/ss-tutorial/_checkpoint"

#Setting for the trigger instructs Structured Streaming to process all previously unprocessed records from the source dataset and then shut down, so you can safely execute the following code without worrying about leaving a stream running:
transformed_df.writeStream.trigger(availableNow=True).option("checkpointLocation", checkpoint_path).option("path", target_path).start()

# COMMAND ----------

#marcas de agua para controlar los umbrales de procesamiento de datos
#Structured Streaming usa marcas de agua para controlar el umbral de cuánto tiempo se siguen procesando las actualizaciones de una entidad de estado determinada
from pyspark.sql.functions import timestamp_seconds
from pyspark.sql.functions import window
#Vamos a usar la columna que hemos creado antes,que contiene la fecha de procesado de los datos
transformed_df.withWatermark("processing_time", "10 minutes").groupBy(
    window("processing_time", "5 minutes"),
    "action","time").count()


# COMMAND ----------

display(transformed_df)

# COMMAND ----------

file_path = "/databricks-datasets/structured-streaming/events"
checkpoint_path = "/tmp/ss-tutorial/_checkpoint"

raw_df = (spark.readStream
    .format("cloudFiles")
    .option("cloudFiles.format", "json")
    .option("cloudFiles.schemaLocation", checkpoint_path)
    .option("checkpointLocation", "/tmp/ss-tutorial/_checkpoint")
    .load(file_path)
)

# COMMAND ----------

