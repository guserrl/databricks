# Databricks notebook source
# MAGIC %sql
# MAGIC --Creamos una tabla apartir de un csv 
# MAGIC --Le indicamos donde tenemos almacenados los datos con path y si tienen cabezera
# MAGIC DROP TABLE IF EXISTS diamonds;
# MAGIC
# MAGIC CREATE TABLE diamonds USING CSV OPTIONS (path "/databricks-datasets/Rdatasets/data-001/csv/ggplot2/diamonds.csv", header "true")

# COMMAND ----------

# MAGIC %python
# MAGIC ##Pasamos los datos a un formato para Delta Lake y creamos la tabla Delta
# MAGIC diamonds = (spark.read
# MAGIC   .format("csv")
# MAGIC   .option("header", "true")
# MAGIC   .option("inferSchema", "true")
# MAGIC   .load("/databricks-datasets/Rdatasets/data-001/csv/ggplot2/diamonds.csv")
# MAGIC )
# MAGIC
# MAGIC diamonds.write.format("delta").mode("overwrite").save("/mnt/delta/diamonds")

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP TABLE IF EXISTS diamonds;
# MAGIC
# MAGIC CREATE TABLE diamonds USING DELTA LOCATION '/mnt/delta/diamonds/'

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC SELECT color, avg(price) AS price FROM diamonds GROUP BY color ORDER BY COLOR
# MAGIC --Podemos mostrar otra forma de visualizar los datos haciendo click en "+"

# COMMAND ----------

##Vamos a configurar un auto-loader para la ingesta de datos en Delta Lake
# Import functions
from pyspark.sql.functions import col, current_timestamp

# Variables a usar en el codigo de abajo
file_path = "/databricks-datasets/structured-streaming/events"
username = spark.sql("SELECT regexp_replace(current_user(), '[^a-zA-Z0-9]', '_')").first()[0]
table_name = f"{username}_etl_quickstart"
checkpoint_path = f"/tmp/{username}/_checkpoint/etl_quickstart"

# Limpiamos los datos de la demo de la tabla
spark.sql(f"DROP TABLE IF EXISTS {table_name}")
dbutils.fs.rm(checkpoint_path, True)

# Configure Auto Loader to ingest JSON data to a Delta table
(spark.readStream
  .format("cloudFiles")
  .option("cloudFiles.format", "json")
  .option("cloudFiles.schemaLocation", checkpoint_path)
  .load(file_path)
  .select("*", col("_metadata.file_path").alias("source_file"), current_timestamp().alias("processing_time"))
  .writeStream
  .option("checkpointLocation", checkpoint_path)
  .trigger(availableNow=True)
  .toTable(table_name))

# COMMAND ----------

df = spark.read.table(table_name)

# COMMAND ----------

display(df)

# COMMAND ----------

##Creacion de una data pipeline
##Ingesta de los datos Songs_data
##No voy a usar Unity Catalog para este ejemplo 
from pyspark.sql.types import DoubleType, IntegerType, StringType, StructType, StructField

# Define variables used in the code below
file_path = "/databricks-datasets/songs/data-001/"
table_name = "raw_song_data"
checkpoint_path = "/tmp/pipeline_get_started/_checkpoint/song_data"
##Esta estructura define como se almacenaran los datos
schema = StructType(
  [
    StructField("artist_id", StringType(), True),
    StructField("artist_lat", DoubleType(), True),
    StructField("artist_long", DoubleType(), True),
    StructField("artist_location", StringType(), True),
    StructField("artist_name", StringType(), True),
    StructField("duration", DoubleType(), True),
    StructField("end_of_fade_in", DoubleType(), True),
    StructField("key", IntegerType(), True),
    StructField("key_confidence", DoubleType(), True),
    StructField("loudness", DoubleType(), True),
    StructField("release", StringType(), True),
    StructField("song_hotnes", DoubleType(), True),
    StructField("song_id", StringType(), True),
    StructField("start_of_fade_out", DoubleType(), True),
    StructField("tempo", DoubleType(), True),
    StructField("time_signature", DoubleType(), True),
    StructField("time_signature_confidence", DoubleType(), True),
    StructField("title", StringType(), True),
    StructField("year", IntegerType(), True),
    StructField("partial_sequence", IntegerType(), True)
  ]
)

(spark.readStream
  .format("cloudFiles")
  .schema(schema)
  .option("cloudFiles.format", "csv")
  .option("sep","\t")
  .load(file_path)
  .writeStream
  .option("checkpointLocation", checkpoint_path)
  .trigger(availableNow=True)
  .toTable(table_name)
)

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE
# MAGIC   prepared_song_data (
# MAGIC     artist_id STRING,
# MAGIC     artist_name STRING,
# MAGIC     duration DOUBLE,
# MAGIC     release STRING,
# MAGIC     tempo DOUBLE,
# MAGIC     time_signature DOUBLE,
# MAGIC     title STRING,
# MAGIC     year DOUBLE,
# MAGIC     processed_time TIMESTAMP
# MAGIC   );
# MAGIC
# MAGIC INSERT INTO
# MAGIC   prepared_song_data
# MAGIC SELECT
# MAGIC   artist_id,
# MAGIC   artist_name,
# MAGIC   duration,
# MAGIC   release,
# MAGIC   tempo,
# MAGIC   time_signature,
# MAGIC   title,
# MAGIC   year,
# MAGIC   current_timestamp()
# MAGIC FROM
# MAGIC   raw_song_data

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Which artists released the most songs each year?
# MAGIC SELECT
# MAGIC   artist_name,count(artist_name) AS num_songs,year
# MAGIC FROM
# MAGIC   prepared_song_data
# MAGIC WHERE
# MAGIC   year > 0
# MAGIC GROUP BY
# MAGIC   artist_name,year
# MAGIC ORDER BY
# MAGIC   num_songs DESC,year DESC

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Find songs for your DJ list
# MAGIC  SELECT
# MAGIC    artist_name,title,tempo
# MAGIC  FROM
# MAGIC    prepared_song_data
# MAGIC  WHERE
# MAGIC    time_signature = 4 AND tempo between 100 and 140;

# COMMAND ----------


uni = (spark.read
  .format("csv")
  .option("header", "true")
  .option("inferSchema", "true")
  .load("C:\Users\guillermo.serrano\Downloads\Clasificacion_Universidades_Espaa.csv")
)

uni.write.format("delta").mode("overwrite").save("/mnt/delta/diamonds")

# COMMAND ----------

