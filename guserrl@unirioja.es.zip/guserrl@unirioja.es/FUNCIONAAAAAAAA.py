# Databricks notebook source
#mE CONECTO A MI ESPACIO DE ALMACENAMIENTO DE AZURE 
spark.conf.set("fs.azure.account.auth.type.guserrlalm.dfs.core.windows.net", "SAS")
spark.conf.set("fs.azure.account.oauth.provider.type.guserrlalm.dfs.core.windows.net", "org.apache.hadoop.fs.azurebfs.sas.FixedSASTokenProvider")
spark.conf.set("fs.azure.sas.fixed.token.guserrlalm.dfs.core.windows.net","?sv=2022-11-02&ss=b&srt=sco&sp=rwdlacyx&se=2023-09-20T17:54:22Z&st=2023-09-20T09:54:22Z&spr=https&sig=CCTh8ih%2FQDI0Kc8L6TXIm3HLodadzXzK4CyUPu7nr0k%3D")


# COMMAND ----------

 #LEO LOS DATOS DEL CSV ALMACENADO EN AZURE
df = spark.read.csv('abfs://guserrl@guserrlalm.dfs.core.windows.net/Day9_MLBPlayers.csv',header=True)
display(df)

# COMMAND ----------

#Transformamos para luego crear nuestar table delta
df.write.format("delta").mode("overwrite").save("/mnt/delta/Day9_MLBPlayers")

# COMMAND ----------

#MUESTRO LOS DATOS
delta_df = spark.read.format("delta").load("/mnt/delta/Day9_MLBPlayers")
display(delta_df)

# COMMAND ----------

# MAGIC %sql
# MAGIC --creamos las tablas
# MAGIC DROP TABLE IF EXISTS Day9_MLBPlayers;
# MAGIC
# MAGIC CREATE TABLE Day9_MLBPlayers USING DELTA LOCATION '/mnt/delta/Day9_MLBPlayers'

# COMMAND ----------

# MAGIC %sql
# MAGIC select ` "Team"`
# MAGIC from Day9_MLBPlayers

# COMMAND ----------

# MAGIC %sql
# MAGIC select *
# MAGIC from Day9_MLBPlayers
# MAGIC where ` "Team"` like "%BAL%"

# COMMAND ----------

