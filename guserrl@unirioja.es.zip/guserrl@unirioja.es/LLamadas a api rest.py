# Databricks notebook source
import http
import json

# COMMAND ----------

conn = http.client.HTTPSConnection("api.postcodes.io")

# COMMAND ----------

payload = ''
headers = {
          'Cookie': '__cfduid=d2e270bea97599e2fbde210bf483fcd491615195032'
          }

# COMMAND ----------

conn.request("GET", "/random/postcodes", payload, headers)
#conn.request("GET", "/scotland/*")

# COMMAND ----------

res = conn.getresponse()
data = res.read().decode("utf-8")
jsondata = json.loads(json.dumps(data))

# COMMAND ----------

df = spark.read.json(sc.parallelize([jsondata]))

# COMMAND ----------

df_temp = df.selectExpr("string(status) as status","result['country'] as country", "result['european_electoral_region'] as european_electoral_region", "string(result['latitude']) as latitude", "string(result['longitude']) as longitude", "result['parliamentary_constituency'] as parliamentary_constituency", "result['region'] as region","'' as vld_status","'' as vld_status_reason")

# COMMAND ----------

df_temp.write.format("delta").mode("append").saveAsTable("postcode")

# COMMAND ----------

# MAGIC %sql
# MAGIC select *
# MAGIC from postcode

# COMMAND ----------

