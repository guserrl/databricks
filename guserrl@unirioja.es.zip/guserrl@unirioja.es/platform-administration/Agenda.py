# Databricks notebook source
# INCLUDE_HEADER_TRUE
# INCLUDE_FOOTER_TRUE

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC # Example Course
# MAGIC ## Course Agenda
# MAGIC
# MAGIC > The course agenda is only required for instructor-led courses. It is generally not included in self-paced courses.<br/>
# MAGIC > Ideally, the agenda would include the estimated duration of the unit, helping the instructor to stay on task and setting expectations for students.